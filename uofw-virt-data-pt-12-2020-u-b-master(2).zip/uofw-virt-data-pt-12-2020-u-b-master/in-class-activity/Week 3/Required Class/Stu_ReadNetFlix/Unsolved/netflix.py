# Modules
import os
import csv

# Prompt user for video lookup


# Set path for file


# Bonus
# ------------------------------------------
# Set variable to check if we found the video


# Open the CSV


# Loop through looking for the video


# BONUS: Set variable to confirm we have found the video


# BONUS: Stop at first results to avoid duplicates


# If the video is never found, alert the user

